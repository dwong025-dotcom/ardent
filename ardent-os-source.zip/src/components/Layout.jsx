import { useMemo, useRef, useState, useEffect } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Calendar, Users, UserRound, ShieldCheck,
  Receipt, BarChart3, MessageSquare, Search, Bell, ExternalLink, Menu, X,
} from 'lucide-react';
import { clients, staff, appointments, invoices, messages, cleanerColours } from '../data/mockData';

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/calendar', label: 'Calendar', icon: Calendar },
  { to: '/clients', label: 'Clients', icon: Users },
  { to: '/staff', label: 'Staff', icon: UserRound },
  { to: '/quality-control', label: 'Quality Control', icon: ShieldCheck },
  { to: '/invoices', label: 'Invoices', icon: Receipt },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
  { to: '/messages', label: 'Messages', icon: MessageSquare },
];

function buildSearchIndex() {
  const idx = [];
  clients.forEach((c) => idx.push({ type: 'Client', label: c.name, sub: c.address, to: `/clients/${c.id}` }));
  staff.forEach((s) => idx.push({ type: 'Staff', label: s.name, sub: s.role, to: '/staff' }));
  appointments.slice(0, 60).forEach((a) =>
    idx.push({ type: 'Appointment', label: `${a.client} · ${a.service}`, sub: `${a.date} at ${a.time}`, to: '/calendar' })
  );
  invoices.forEach((i) => idx.push({ type: 'Invoice', label: `${i.id} · ${i.client}`, sub: `£${i.amount} · ${i.status}`, to: '/invoices' }));
  messages.forEach((m) => idx.push({ type: 'Message', label: m.author, sub: m.text, to: '/messages' }));
  return idx;
}
const searchIndex = buildSearchIndex();

export default function Layout({ children }) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const navigate = useNavigate();
  const boxRef = useRef(null);

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return searchIndex.filter((r) => r.label.toLowerCase().includes(q) || r.sub?.toLowerCase().includes(q)).slice(0, 8);
  }, [query]);

  useEffect(() => {
    function onClick(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  function goTo(to) {
    navigate(to);
    setQuery('');
    setOpen(false);
  }

  return (
    <div className="min-h-screen flex bg-warmwhite">
      {mobileNavOpen && (
        <div className="fixed inset-0 bg-charcoal/30 z-30 md:hidden" onClick={() => setMobileNavOpen(false)} />
      )}

      <aside
        className={`w-64 shrink-0 border-r border-black/[0.05] flex flex-col py-6 px-4 bg-warmwhite fixed md:static inset-y-0 left-0 z-40 transition-transform duration-200 ${
          mobileNavOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="px-2 mb-8 flex items-center justify-between">
          <div>
            <div className="font-display text-xl text-charcoal tracking-tight">Ardent OS</div>
            <div className="text-xs text-charcoal-soft mt-0.5">Business Operating System</div>
          </div>
          <button className="md:hidden text-charcoal-soft" onClick={() => setMobileNavOpen(false)} aria-label="Close menu">
            <X size={18} />
          </button>
        </div>

        <nav className="flex-1 space-y-1">
          {navItems.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={() => setMobileNavOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-2xl text-[15px] transition-all duration-150 ${
                  isActive
                    ? 'bg-teal text-white shadow-[var(--shadow-soft)]'
                    : 'text-charcoal-soft hover:bg-sage-light hover:text-charcoal hover:translate-x-0.5'
                }`
              }
            >
              <Icon size={18} strokeWidth={1.75} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="px-3 pt-4 border-t border-black/[0.05] space-y-2">
          <Link to="/marketing" className="flex items-center gap-2 text-xs text-charcoal-soft hover:text-teal transition-colors">
            <ExternalLink size={13} />
            View marketing page
          </Link>
          <div className="text-[11px] text-charcoal-soft/70">powered by Simputic</div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 shrink-0 border-b border-black/[0.05] flex items-center justify-between px-4 md:px-8 bg-warmwhite/80 backdrop-blur sticky top-0 z-20">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <button className="md:hidden text-charcoal-soft p-1" onClick={() => setMobileNavOpen(true)} aria-label="Open menu">
              <Menu size={20} />
            </button>
            <div className="relative w-full max-w-sm" ref={boxRef}>
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal-soft" />
              <input
                type="text"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
                onFocus={() => setOpen(true)}
                placeholder="Search clients, staff, invoices…"
                className="w-full bg-white border border-black/[0.06] rounded-2xl pl-9 pr-3 py-2 text-sm placeholder:text-charcoal-soft/70 focus:border-teal/40 transition-colors"
              />
              {open && results.length > 0 && (
                <div className="absolute top-full mt-2 left-0 right-0 bg-white border border-black/[0.06] rounded-2xl shadow-[var(--shadow-card)] overflow-hidden z-30">
                  {results.map((r, i) => (
                    <button
                      key={i}
                      onClick={() => goTo(r.to)}
                      className="w-full text-left px-4 py-2.5 hover:bg-sage-light/60 transition-colors flex items-center justify-between gap-3 border-b border-black/[0.04] last:border-0"
                    >
                      <div className="min-w-0">
                        <div className="text-sm text-charcoal truncate">{r.label}</div>
                        <div className="text-xs text-charcoal-soft truncate">{r.sub}</div>
                      </div>
                      <span className="text-[10px] uppercase tracking-wide text-teal shrink-0">{r.type}</span>
                    </button>
                  ))}
                </div>
              )}
              {open && query.trim() && results.length === 0 && (
                <div className="absolute top-full mt-2 left-0 right-0 bg-white border border-black/[0.06] rounded-2xl shadow-[var(--shadow-card)] p-4 text-sm text-charcoal-soft z-30">
                  No matches for "{query}".
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4 pl-3">
            <button className="relative text-charcoal-soft hover:text-charcoal transition-colors" aria-label="Notifications">
              <Bell size={19} strokeWidth={1.75} />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-status-red rounded-full" />
            </button>
            <div className="w-9 h-9 rounded-full bg-teal text-white flex items-center justify-center font-display text-sm shrink-0">
              CK
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 md:px-8 py-6 md:py-7 max-w-[1400px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
