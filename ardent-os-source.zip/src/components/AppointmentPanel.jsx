import { X, MapPin, Phone, Mail, Repeat, PawPrint, KeyRound, Car, ClipboardCheck, Camera, Receipt, History } from 'lucide-react';
import { Link } from 'react-router-dom';
import { clients, cleanerColours } from '../data/mockData';
import { AISummary, CleanerAvatarStack, StatusPill } from './ui';

export default function AppointmentPanel({ appointment, onClose }) {
  if (!appointment) return null;
  const client = clients.find((c) => c.id === appointment.clientId);
  if (!client) return null;

  const lastVisit = client.history?.[0];

  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0 bg-charcoal/20 backdrop-blur-[1px]" onClick={onClose} />
      <div className="relative w-full max-w-md h-full bg-warmwhite border-l border-black/[0.06] shadow-2xl overflow-y-auto">
        <div className="sticky top-0 bg-warmwhite/90 backdrop-blur px-6 pt-6 pb-4 border-b border-black/[0.05] flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-teal font-medium mb-1">
              {appointment.service}
              {appointment.status && <StatusPill status={appointment.status} />}
            </div>
            <h2 className="font-display text-2xl text-charcoal leading-tight">{client.name}</h2>
            <div className="text-sm text-charcoal-soft mt-1">
              {appointment.date.split('-').reverse().join('/')} · {appointment.time} · {appointment.duration} min
            </div>
          </div>
          <button onClick={onClose} className="text-charcoal-soft hover:text-charcoal p-1" aria-label="Close">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Customer summary */}
          <div>
            <SectionLabel>Customer Summary</SectionLabel>
            <div className="space-y-2 text-sm bg-white rounded-2xl p-3.5 border border-black/[0.05]">
              <a href="#" onClick={(e) => e.preventDefault()} className="flex items-center gap-2.5 text-charcoal hover:text-teal transition-colors">
                <MapPin size={16} className="text-charcoal-soft shrink-0" /> {client.address}
              </a>
              <div className="flex items-center gap-2.5 text-charcoal">
                <Phone size={16} className="text-charcoal-soft shrink-0" /> {client.phone}
              </div>
              <div className="flex items-center gap-2.5 text-charcoal">
                <Mail size={16} className="text-charcoal-soft shrink-0" /> {client.email}
              </div>
              <div className="flex items-center gap-2.5 text-charcoal">
                <Repeat size={16} className="text-charcoal-soft shrink-0" /> {client.frequency} recurring · client since {client.since}
              </div>
            </div>
          </div>

          {/* Maps */}
          <div className="rounded-2xl overflow-hidden border border-black/[0.05] bg-sage-light/50 h-28 flex items-center justify-center text-charcoal-soft text-xs relative">
            <MapPin size={16} className="mr-1.5" /> Map preview — {client.address.split(',').slice(-2, -1)[0]?.trim()}
          </div>

          <AISummary>{client.aiSummary}</AISummary>

          {/* Cleaner assignment */}
          <div>
            <SectionLabel>Cleaner Assignment</SectionLabel>
            <div className="bg-white rounded-2xl p-3.5 border border-black/[0.05] flex items-center gap-3">
              <CleanerAvatarStack primary={appointment.cleaner} secondary={appointment.secondaryCleaner} size={30} />
              <div className="text-sm text-charcoal">
                {[appointment.cleaner, appointment.secondaryCleaner].filter(Boolean).map((id) => cleanerColours[id]?.name).join(' & ')}
              </div>
            </div>
          </div>

          {/* Property information */}
          <div>
            <SectionLabel>Property Information</SectionLabel>
            <div className="grid grid-cols-2 gap-3">
              <InfoBlock icon={PawPrint} label="Pets" value={client.pets} />
              <InfoBlock icon={KeyRound} label="Access code" value={client.alarmCode} />
              <InfoBlock icon={Car} label="Parking" value={client.parking} className="col-span-2" />
            </div>
          </div>

          {/* Special instructions */}
          <div>
            <SectionLabel>Special Instructions</SectionLabel>
            <p className="text-sm text-charcoal-soft leading-relaxed bg-white rounded-2xl p-3.5 border border-black/[0.05]">
              {client.notes}
              {client.prefersEco && ' Client prefers eco-friendly products.'}
            </p>
          </div>

          {/* Visit history */}
          <div>
            <SectionLabel>Visit History</SectionLabel>
            <div className="space-y-2">
              {client.history?.length ? client.history.slice(0, 3).map((h, i) => (
                <div key={i} className="flex items-center justify-between bg-white rounded-2xl p-3 border border-black/[0.05] text-sm">
                  <span className="text-charcoal">{h.date} · {cleanerColours[h.cleaner]?.name}</span>
                  <StatusPill status={h.qc} />
                </div>
              )) : (
                <div className="text-sm text-charcoal-soft bg-white rounded-2xl p-3.5 border border-black/[0.05]">No previous visits on record yet.</div>
              )}
            </div>
          </div>

          {/* Previous visit summary */}
          {lastVisit && (
            <div>
              <SectionLabel>Previous Visit Summary</SectionLabel>
              <div className="flex items-start gap-2.5 bg-white rounded-2xl p-3.5 border border-black/[0.05] text-sm text-charcoal-soft">
                <History size={15} className="mt-0.5 shrink-0 text-charcoal-soft" />
                Last visited {lastVisit.date} by {cleanerColours[lastVisit.cleaner]?.name}, marked {lastVisit.qc.toLowerCase()}.
              </div>
            </div>
          )}

          {/* QC + invoice */}
          <div className="flex items-center justify-between bg-white rounded-2xl p-3.5 border border-black/[0.05]">
            <div className="flex items-center gap-2 text-sm text-charcoal">
              <ClipboardCheck size={16} className="text-charcoal-soft" /> Quality check
            </div>
            <StatusPill status={lastVisit?.qc || 'Pending'} />
          </div>

          <div className="flex items-center justify-between bg-white rounded-2xl p-3.5 border border-black/[0.05]">
            <div className="flex items-center gap-2 text-sm text-charcoal">
              <Camera size={16} className="text-charcoal-soft" /> Before / after photos
            </div>
            <span className="text-xs text-charcoal-soft">None uploaded yet</span>
          </div>

          <div className="flex items-center justify-between bg-white rounded-2xl p-3.5 border border-black/[0.05]">
            <div className="flex items-center gap-2 text-sm text-charcoal">
              <Receipt size={16} className="text-charcoal-soft" /> Invoice status
            </div>
            <StatusPill status={client.balance > 0 ? 'Overdue' : 'Paid'} />
          </div>

          <Link
            to={`/clients/${client.id}`}
            className="block text-center py-2.5 rounded-2xl bg-teal text-white text-sm hover:bg-teal-dark transition-colors"
          >
            View full client profile
          </Link>
        </div>
      </div>
    </div>
  );
}

function SectionLabel({ children }) {
  return <div className="text-[11px] uppercase tracking-wide text-charcoal-soft font-medium mb-2">{children}</div>;
}

function InfoBlock({ icon: Icon, label, value, className = '' }) {
  return (
    <div className={`bg-white rounded-2xl p-3 border border-black/[0.05] ${className}`}>
      <div className="flex items-center gap-1.5 text-xs text-charcoal-soft mb-1">
        <Icon size={13} /> {label}
      </div>
      <div className="text-sm text-charcoal">{value}</div>
    </div>
  );
}
