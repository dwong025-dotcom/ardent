import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, MapPin, Phone, Clock } from 'lucide-react';
import { appointments, cleanerColours, staff } from '../data/mockData';
import { SectionHeading, StatusPill, CleanerAvatarStack, EmptyState } from '../components/ui';
import AppointmentPanel from '../components/AppointmentPanel';

const weekdayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function toKey(d) {
  return d.toISOString().slice(0, 10);
}
function startOfWeek(date) {
  const d = new Date(date);
  const day = (d.getDay() + 6) % 7; // Monday = 0
  d.setDate(d.getDate() - day);
  d.setHours(0, 0, 0, 0);
  return d;
}
function startOfMonthGrid(date) {
  const first = new Date(date.getFullYear(), date.getMonth(), 1);
  return startOfWeek(first);
}

export default function CalendarPage() {
  const [view, setView] = useState('week');
  const [anchor, setAnchor] = useState(new Date('2026-07-14'));
  const [selected, setSelected] = useState(null);

  const apptsByDate = useMemo(() => {
    const map = {};
    appointments.forEach((a) => {
      (map[a.date] ||= []).push(a);
    });
    Object.values(map).forEach((list) => list.sort((a, b) => a.time.localeCompare(b.time)));
    return map;
  }, []);

  function shift(amount) {
    const d = new Date(anchor);
    if (view === 'month') d.setMonth(d.getMonth() + amount);
    else if (view === 'week') d.setDate(d.getDate() + amount * 7);
    else d.setDate(d.getDate() + amount);
    setAnchor(d);
  }

  const label = useMemo(() => {
    if (view === 'month') return anchor.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
    if (view === 'day') return anchor.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
    const start = startOfWeek(anchor);
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return `${start.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} – ${end.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}`;
  }, [anchor, view]);

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Schedule"
        title="Calendar"
        action={
          <button className="flex items-center gap-1.5 bg-teal text-white text-sm px-4 py-2 rounded-2xl hover:bg-teal-dark transition-colors">
            <Plus size={16} /> New appointment
          </button>
        }
      />

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <button onClick={() => shift(-1)} className="p-2 rounded-xl hover:bg-sage-light text-charcoal-soft transition-colors" aria-label="Previous">
            <ChevronLeft size={18} />
          </button>
          <div className="font-display text-lg text-charcoal min-w-[200px] text-center">{label}</div>
          <button onClick={() => shift(1)} className="p-2 rounded-xl hover:bg-sage-light text-charcoal-soft transition-colors" aria-label="Next">
            <ChevronRight size={18} />
          </button>
          <button
            onClick={() => setAnchor(new Date('2026-07-14'))}
            className="ml-2 text-xs text-teal border border-teal/30 rounded-xl px-3 py-1.5 hover:bg-teal-light transition-colors"
          >
            Today
          </button>
        </div>

        <div className="hidden md:flex items-center bg-sage-light rounded-2xl p-1 gap-1">
          {['month', 'week', 'day'].map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-3.5 py-1.5 rounded-xl text-sm capitalize transition-colors ${
                view === v ? 'bg-white text-charcoal shadow-sm' : 'text-charcoal-soft'
              }`}
            >
              {v}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-4 flex-wrap">
        {staff.map((s) => (
          <div key={s.id} className="flex items-center gap-1.5 text-xs text-charcoal-soft">
            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.colour }} />
            {s.name.split(' ')[0]}
          </div>
        ))}
      </div>

      {/* Mobile always gets a calm agenda list, regardless of the desktop view toggle */}
      <div className="md:hidden">
        <AgendaView anchor={anchor} apptsByDate={apptsByDate} onSelect={setSelected} />
      </div>

      <div className="hidden md:block">
        {view === 'month' && <MonthView anchor={anchor} apptsByDate={apptsByDate} onSelect={setSelected} />}
        {view === 'week' && <WeekView anchor={anchor} apptsByDate={apptsByDate} onSelect={setSelected} />}
        {view === 'day' && <DayView anchor={anchor} apptsByDate={apptsByDate} onSelect={setSelected} />}
      </div>

      <AppointmentPanel appointment={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

function ApptTooltip({ a }) {
  return (
    <div className="absolute z-50 left-1/2 -translate-x-1/2 bottom-[calc(100%+8px)] w-64 bg-charcoal text-warmwhite rounded-2xl p-4 shadow-2xl opacity-0 scale-95 pointer-events-none group-hover:opacity-100 group-hover:scale-100 transition-all duration-150 origin-bottom">
      <div className="font-display text-[15px] mb-1">{a.client}</div>
      <div className="flex items-start gap-1.5 text-xs text-warmwhite/70 mb-2">
        <MapPin size={12} className="mt-0.5 shrink-0" /> {a.address}
      </div>
      <div className="flex items-center gap-1.5 text-xs text-warmwhite/70 mb-2">
        <Phone size={12} /> {a.phone}
      </div>
      <div className="flex items-center gap-1.5 text-xs text-warmwhite/70 mb-2">
        <Clock size={12} /> {a.time} · {a.duration} min
      </div>
      <div className="text-xs text-warmwhite/90 mb-2">{a.service}</div>
      <div className="flex items-center justify-between">
        <span className="text-xs text-gold">
          {[a.cleaner, a.secondaryCleaner].filter(Boolean).map((id) => cleanerColours[id]?.name).join(' & ')}
        </span>
        <StatusPill status={a.status} />
      </div>
    </div>
  );
}

function ApptCard({ a, onSelect, compact }) {
  const colour = cleanerColours[a.cleaner]?.hex;
  return (
    <button
      onClick={() => onSelect(a)}
      className="group relative w-full text-left rounded-xl px-2.5 py-1.5 mb-1 border transition-all hover:-translate-y-[1px] hover:shadow-[var(--shadow-soft)]"
      style={{ backgroundColor: `${colour}14`, borderColor: `${colour}33` }}
    >
      <ApptTooltip a={a} />
      <div className="flex items-center justify-between gap-1.5">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: colour }} />
          <span className="text-xs font-medium text-charcoal truncate">{a.time}</span>
        </div>
        {a.secondaryCleaner && <CleanerAvatarStack primary={a.cleaner} secondary={a.secondaryCleaner} size={14} />}
      </div>
      <div className="text-xs text-charcoal-soft truncate">{a.client}</div>
      {!compact && <div className="text-[11px] text-charcoal-soft/70 truncate">{a.service}</div>}
    </button>
  );
}

function MonthView({ anchor, apptsByDate, onSelect }) {
  const gridStart = startOfMonthGrid(anchor);
  const days = Array.from({ length: 42 }, (_, i) => {
    const d = new Date(gridStart);
    d.setDate(d.getDate() + i);
    return d;
  });
  const currentMonth = anchor.getMonth();

  return (
    <div className="bg-card rounded-3xl border border-black/[0.04] shadow-[var(--shadow-card)] overflow-visible">
      <div className="grid grid-cols-7 border-b border-black/[0.05]">
        {weekdayLabels.map((d) => (
          <div key={d} className="text-xs text-charcoal-soft font-medium py-3 text-center">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {days.map((d, i) => {
          const key = toKey(d);
          const list = apptsByDate[key] || [];
          const inMonth = d.getMonth() === currentMonth;
          return (
            <div
              key={i}
              className={`min-h-[110px] p-2 border-b border-r border-black/[0.04] ${i % 7 === 6 ? 'border-r-0' : ''} ${
                inMonth ? '' : 'bg-warmwhite/60'
              }`}
            >
              <div className={`text-xs mb-1.5 ${inMonth ? 'text-charcoal' : 'text-charcoal-soft/50'}`}>{d.getDate()}</div>
              {list.slice(0, 2).map((a) => (
                <ApptCard key={a.id} a={a} onSelect={onSelect} compact />
              ))}
              {list.length > 2 && <div className="text-[11px] text-charcoal-soft pl-1">+{list.length - 2} more</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function WeekView({ anchor, apptsByDate, onSelect }) {
  const start = startOfWeek(anchor);
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    return d;
  });

  return (
    <div className="bg-card rounded-3xl border border-black/[0.04] shadow-[var(--shadow-card)] overflow-visible">
      <div className="grid grid-cols-7 border-b border-black/[0.05]">
        {days.map((d, i) => (
          <div key={i} className="text-center py-3 border-r border-black/[0.04] last:border-r-0">
            <div className="text-xs text-charcoal-soft font-medium">{weekdayLabels[i]}</div>
            <div className="font-display text-lg text-charcoal">{d.getDate()}</div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 min-h-[420px]">
        {days.map((d, i) => {
          const key = toKey(d);
          const list = apptsByDate[key] || [];
          return (
            <div key={i} className="p-2 border-r border-black/[0.04] last:border-r-0 overflow-visible">
              {list.length === 0 && <div className="text-[11px] text-charcoal-soft/50 pt-2 text-center">—</div>}
              {list.map((a) => (
                <ApptCard key={a.id} a={a} onSelect={onSelect} />
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DayView({ anchor, apptsByDate, onSelect }) {
  const key = toKey(anchor);
  const list = apptsByDate[key] || [];
  const hours = Array.from({ length: 11 }, (_, i) => i + 7); // 7am-5pm

  return (
    <div className="bg-card rounded-3xl border border-black/[0.04] shadow-[var(--shadow-card)] p-4">
      {list.length === 0 ? (
        <EmptyState title="No appointments scheduled" body="This day is clear — a good moment to fit in a one-off or catch up on admin." />
      ) : (
        <div className="divide-y divide-black/[0.04]">
          {hours.map((h) => {
            const slotAppts = list.filter((a) => parseInt(a.time.split(':')[0], 10) === h);
            return (
              <div key={h} className="flex gap-4 py-3">
                <div className="w-16 text-xs text-charcoal-soft font-mono pt-1 shrink-0">
                  {h > 12 ? `${h - 12}pm` : `${h}am`}
                </div>
                <div className="flex-1 space-y-2">
                  {slotAppts.map((a) => (
                    <ApptCard key={a.id} a={a} onSelect={onSelect} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function AgendaView({ anchor, apptsByDate, onSelect }) {
  const start = startOfWeek(anchor);
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    return d;
  });

  return (
    <div className="space-y-4">
      {days.map((d, i) => {
        const key = toKey(d);
        const list = apptsByDate[key] || [];
        if (list.length === 0) return null;
        return (
          <div key={i} className="bg-card rounded-3xl border border-black/[0.04] shadow-[var(--shadow-card)] p-4">
            <div className="text-sm font-display text-charcoal mb-2">
              {weekdayLabels[i]} {d.getDate()}
            </div>
            <div className="space-y-2">
              {list.map((a) => (
                <button
                  key={a.id}
                  onClick={() => onSelect(a)}
                  className="w-full text-left flex items-center justify-between gap-2 p-3 rounded-2xl bg-warmwhite"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: cleanerColours[a.cleaner]?.hex }} />
                    <div className="min-w-0">
                      <div className="text-sm text-charcoal truncate">{a.time} · {a.client}</div>
                      <div className="text-xs text-charcoal-soft truncate">{a.service}</div>
                    </div>
                  </div>
                  <StatusPill status={a.status} />
                </button>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
