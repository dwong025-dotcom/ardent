// GET /.netlify/functions/appointments
//
// PRIMARY RELATIONSHIP: Job Appointments.Cleaners (a real Airtable
// linked-record field pointing at Staff) is used for every appointment that
// has it. This requires no ID-matching — the linked Staff records are
// resolved directly.
//
// FALLBACK (not part of the normal data flow): only when an appointment has
// no Cleaners link is Job Assignments consulted, matching on
// Customer ID + Appointment Date + Start Time. This path is logged every
// time it fires, never invents a cleaner when the match is ambiguous, never
// creates a duplicate appointment, and deduplicates cleaner IDs.

const { listAllRecords, jsonResponse } = require('./_airtable');

function toMinutes(raw) {
  if (!raw) return null;
  const s = String(raw).trim();
  let m = s.match(/^(\d{1,2}):(\d{2})$/);
  if (m) return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
  m = s.match(/^(\d{1,2}):(\d{2})\s*([APap][Mm])$/);
  if (m) {
    let h = parseInt(m[1], 10) % 12;
    if (/pm/i.test(m[3])) h += 12;
    return h * 60 + parseInt(m[2], 10);
  }
  return null;
}

function compositeKey(customerId, date, startTime) {
  if (customerId == null || !date || !startTime) return null;
  return `${customerId}|${date}|${startTime}`;
}

function buildAddress(f) {
  return [f['Address Line 1'], f['Address Line 2'], f['Postcode']].filter(Boolean).join(', ');
}

exports.handler = async function handler() {
  try {
    // --- Staff, needed to resolve the Cleaners link field to cleaner IDs ---
    const staffRecords = await listAllRecords('Staff', {
      fields: ['Cleaner ID', 'Staff Name'],
    });
    const staffByRecordId = new Map(
      staffRecords.map((r) => [
        r.id,
        { id: r.fields['Cleaner ID'] != null ? String(r.fields['Cleaner ID']) : r.id, name: r.fields['Staff Name'] || '' },
      ])
    );

    // --- Job Appointments, the sole appointment list ---
    const apptRecords = await listAllRecords('Job Appointments', {
      fields: [
        'Appointment ID', 'Appointment Date', 'Start Time', 'End Time',
        'Appointment Status', 'Service Type', 'Address Line 1', 'Address Line 2',
        'Postcode', 'Customer ID', 'Customer Full name', 'Cleaners',
      ],
    });

    // Detect composite-key collisions on the appointment side up front, so the
    // fallback never guesses which of several same-keyed appointments a
    // Job Assignments row actually belongs to.
    const apptKeyCounts = new Map();
    apptRecords.forEach((r) => {
      const f = r.fields;
      const key = compositeKey(f['Customer ID'], f['Appointment Date'], f['Start Time']);
      if (key) apptKeyCounts.set(key, (apptKeyCounts.get(key) || 0) + 1);
    });

    const needsFallback = apptRecords.some((r) => !(r.fields['Cleaners'] || []).length);

    // --- Job Assignments: only fetched at all if at least one appointment needs it ---
    let assignmentsByKey = new Map();
    if (needsFallback) {
      const assignmentRecords = await listAllRecords('Job Assignments', {
        fields: ['Customer ID', 'Appointment Date', 'Appointment Start Time', 'Assigned Staff'],
      });
      assignmentRecords.forEach((r) => {
        const f = r.fields;
        const key = compositeKey(f['Customer ID'], f['Appointment Date'], f['Appointment Start Time']);
        if (!key) return;
        const staffLinks = f['Assigned Staff'] || [];
        staffLinks.forEach((staffRecId) => {
          const staff = staffByRecordId.get(staffRecId);
          if (!staff) return;
          if (!assignmentsByKey.has(key)) assignmentsByKey.set(key, new Map());
          assignmentsByKey.get(key).set(staff.id, staff); // Map dedupes by cleaner id automatically
        });
      });
      console.log(`[appointments] fallback path active: ${assignmentRecords.length} Job Assignments loaded for lookup.`);
    }

    let fallbackUsed = 0;
    let fallbackUnmatched = 0;
    let fallbackAmbiguous = 0;

    const appointments = apptRecords.map((r) => {
      const f = r.fields;
      const apptId = f['Appointment ID'];
      const customerId = f['Customer ID'];
      const date = f['Appointment Date'];
      const startTime = f['Start Time'];
      const endTime = f['End Time'];
      const startMin = toMinutes(startTime);
      const endMin = toMinutes(endTime);

      let cleanerLinks = (f['Cleaners'] || [])
        .map((recId) => staffByRecordId.get(recId))
        .filter(Boolean);
      let source = 'cleaners-link';

      if (cleanerLinks.length === 0) {
        const key = compositeKey(customerId, date, startTime);
        const collision = key && apptKeyCounts.get(key) > 1;

        if (!key || collision) {
          if (collision) {
            fallbackAmbiguous += 1;
            console.warn(`[appointments] AMBIGUOUS fallback for Appointment ID ${apptId}: composite key "${key}" matches more than one Job Appointment. Cleaner left unassigned rather than guessed.`);
          }
          source = collision ? 'ambiguous' : 'unmatched';
        } else {
          const matches = assignmentsByKey.get(key);
          if (matches && matches.size > 0) {
            cleanerLinks = Array.from(matches.values());
            source = 'assignments-fallback';
            fallbackUsed += 1;
            console.log(`[appointments] Fallback match for Appointment ID ${apptId} via Job Assignments (key "${key}") -> ${cleanerLinks.map((c) => c.name).join(', ')}`);
          } else {
            fallbackUnmatched += 1;
            source = 'unmatched';
          }
        }
      }

      return {
        id: `apt-${apptId}`,
        clientId: customerId != null ? String(customerId) : null,
        client: f['Customer Full name'] || (customerId != null ? `Client #${customerId}` : 'Unknown client'),
        address: buildAddress(f),
        date,
        time: startTime || '',
        endTime: endTime || '',
        duration: startMin != null && endMin != null && endMin > startMin ? endMin - startMin : null,
        service: f['Service Type'] || '',
        status: f['Appointment Status'] || '',
        cleaner: cleanerLinks[0]?.id || null,
        secondaryCleaner: cleanerLinks[1]?.id || null,
        cleanerSource: source, // debug/transparency field; not required by the UI
      };
    });

    console.log(`[appointments] done. total=${appointments.length} fallbackUsed=${fallbackUsed} fallbackUnmatched=${fallbackUnmatched} fallbackAmbiguous=${fallbackAmbiguous}`);

    return jsonResponse(200, { appointments });
  } catch (err) {
    console.error('[appointments] failed:', err);
    return jsonResponse(500, { error: err.message });
  }
};
