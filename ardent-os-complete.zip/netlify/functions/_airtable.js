// Shared server-side Airtable helper.
//
// SECURITY: this file only ever runs on the server (Netlify Functions).
// It reads AIRTABLE_TOKEN / AIRTABLE_BASE_ID from plain (non-VITE_) Netlify
// environment variables. Nothing in this file is ever bundled into the
// browser build — Vite only inlines variables prefixed VITE_, and this file
// lives outside src/, so it is never touched by the Vite build at all.

const AIRTABLE_API_URL = 'https://api.airtable.com/v0';

function getConfig() {
  const token = process.env.AIRTABLE_TOKEN;
  const baseId = process.env.AIRTABLE_BASE_ID;
  if (!token || !baseId) {
    throw new Error(
      'Airtable is not configured on the server. Set AIRTABLE_TOKEN and ' +
      'AIRTABLE_BASE_ID as Netlify environment variables (Site settings -> ' +
      'Environment variables). Do not use VITE_ prefixed names for these.'
    );
  }
  return { token, baseId };
}

// Fetches every record from an Airtable table, following pagination.
// `params` accepts any Airtable list-records query params (fields, filterByFormula, etc).
async function listAllRecords(tableName, params = {}) {
  const { token, baseId } = getConfig();
  const records = [];
  let offset;

  do {
    const url = new URL(`${AIRTABLE_API_URL}/${baseId}/${encodeURIComponent(tableName)}`);
    Object.entries(params).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        value.forEach((v) => url.searchParams.append(key, v));
      } else if (value !== undefined) {
        url.searchParams.set(key, value);
      }
    });
    if (offset) url.searchParams.set('offset', offset);

    const res = await fetch(url.toString(), {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`Airtable request failed (${tableName}): ${res.status} ${body}`);
    }

    const data = await res.json();
    records.push(...data.records);
    offset = data.offset;
  } while (offset);

  return records;
}

function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  };
}

module.exports = { listAllRecords, jsonResponse };
