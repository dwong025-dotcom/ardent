// GET /.netlify/functions/staff
//
// Returns the Staff table, normalized to the shape the frontend expects.
//
// Known gap: the Airtable Staff table does not have Role, Availability,
// Emergency Contact, Hours This Week, live Status, or a Colour field.
// Those come back as safe defaults below rather than being invented.
// Colour is resolved by the frontend's cleaner registry (src/lib/cleanerRegistry.js)
// so appointment badges/dots stay visually consistent even without a Colour field.

const { listAllRecords, jsonResponse } = require('./_airtable');

function initials(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
}

exports.handler = async function handler() {
  try {
    const records = await listAllRecords('Staff', {
      fields: ['Staff Name', 'Cleaner ID', 'Mobile Number', 'Notes', 'Average QC Rating'],
    });

    const staff = records.map((r) => {
      const f = r.fields;
      const cleanerId = f['Cleaner ID'] != null ? String(f['Cleaner ID']) : r.id;
      return {
        id: cleanerId,
        airtableId: r.id,
        name: f['Staff Name'] || 'Unnamed',
        photo: initials(f['Staff Name']),
        phone: f['Mobile Number'] || '',
        notes: f['Notes'] || '',
        qcRating: typeof f['Average QC Rating'] === 'number' ? f['Average QC Rating'] : null,
        // Not available from Airtable yet — surfaced as empty/unknown rather than guessed.
        role: '',
        availability: '',
        emergencyContact: '',
        hoursThisWeek: null,
        status: 'Unknown',
      };
    });

    return jsonResponse(200, { staff });
  } catch (err) {
    console.error('[staff] failed:', err);
    return jsonResponse(500, { error: err.message });
  }
};
