import { HashRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import CalendarPage from './pages/CalendarPage';
import Clients from './pages/Clients';
import ClientDetail from './pages/ClientDetail';
import Staff from './pages/Staff';
import QualityControl from './pages/QualityControl';
import Invoices from './pages/Invoices';
import Reports from './pages/Reports';
import Messages from './pages/Messages';
import Marketing from './pages/Marketing';

function AppShell() {
  return (
    <Routes>
      <Route path="/marketing" element={<Marketing />} />
      <Route
        path="/*"
        element={
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/calendar" element={<CalendarPage />} />
              <Route path="/clients" element={<Clients />} />
              <Route path="/clients/:id" element={<ClientDetail />} />
              <Route path="/staff" element={<Staff />} />
              <Route path="/quality-control" element={<QualityControl />} />
              <Route path="/invoices" element={<Invoices />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/messages" element={<Messages />} />
            </Routes>
          </Layout>
        }
      />
    </Routes>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AppShell />
    </HashRouter>
  );
}
