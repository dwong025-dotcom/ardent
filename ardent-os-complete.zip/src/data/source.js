// Data abstraction layer for Phase 1 (Staff + Job Appointments only).
//
// Pages call fetchStaff()/fetchAppointments() instead of importing mockData.js
// or an Airtable client directly. VITE_USE_MOCK_DATA only ever holds the
// string 'true' or 'false' — no secrets travel through it, and it is safe to
// expose to the browser since it carries no credentials.
//
// Everything else (Clients, Quality Checks, Invoices, Messages) is still out
// of scope for Phase 1 and continues to be imported directly from
// mockData.js by the pages that use it.

import { staff as mockStaff, appointments as mockAppointments } from './mockData';
import { registerCleaners, getCleaner } from '../lib/cleanerRegistry';

// Defaults to mock data if the flag is missing entirely, so a misconfigured
// deploy fails safe (shows the demo) rather than failing open (breaks the app).
export const USE_MOCK_DATA = (import.meta.env.VITE_USE_MOCK_DATA ?? 'true') !== 'false';

async function callFunction(name) {
  const res = await fetch(`/.netlify/functions/${name}`);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request to ${name} failed (${res.status})`);
  }
  return res.json();
}

export async function fetchStaff() {
  if (USE_MOCK_DATA) {
    registerCleaners(mockStaff);
    return mockStaff;
  }
  const { staff } = await callFunction('staff');
  registerCleaners(staff);
  // mock staff already carry a `colour` field baked in from mockData.js; live
  // staff don't (Airtable has no Colour field), so attach it here from the
  // registry — every page that reads `s.colour` directly keeps working.
  return staff.map((s) => ({ ...s, colour: getCleaner(s.id).hex }));
}

export async function fetchAppointments() {
  if (USE_MOCK_DATA) return mockAppointments;
  const { appointments } = await callFunction('appointments');
  return appointments;
}
