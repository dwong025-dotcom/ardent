// Ardent OS — mock data
// Single seam for future Airtable integration: every page reads from the
// arrays exported here. Swap the contents for live Airtable records and nothing
// downstream needs to change.

export const TODAY = '2026-07-14'; // Tuesday
export const NOW_MINUTES = 10 * 60 + 40; // ~10:40am, used to derive live-feeling staff status

export const cleanerColours = {
  charlotte: { hex: '#0F766E', name: 'Charlotte' }, // teal
  emma: { hex: '#3B6FA3', name: 'Emma' }, // blue
  jenny: { hex: '#4C8C5B', name: 'Jenny' }, // green
  karolina: { hex: '#C98A2E', name: 'Karolina' }, // amber
  vicki: { hex: '#7B5EA7', name: 'Vicki' }, // purple
  shamsun: { hex: '#C45C7C', name: 'Shamsun' }, // rose
};

export const staff = [
  {
    id: 'charlotte',
    name: 'Charlotte Kebble',
    colour: cleanerColours.charlotte.hex,
    photo: 'CK',
    role: 'Owner & Senior Cleaner',
    phone: '07700 900 101',
    emergencyContact: 'Ryan Kebble · 07700 900 102',
    availability: 'Mon–Fri, 8am–4pm',
    hoursThisWeek: 34,
    status: 'On Site',
    qcRating: 4.9,
  },
  {
    id: 'emma',
    name: 'Emma Whitlock',
    colour: cleanerColours.emma.hex,
    photo: 'EW',
    role: 'Senior Cleaner',
    phone: '07700 900 221',
    emergencyContact: 'Daniel Whitlock · 07700 900 222',
    availability: 'Mon–Fri, 8am–5pm',
    hoursThisWeek: 36,
    status: 'Travelling',
    qcRating: 4.8,
  },
  {
    id: 'jenny',
    name: 'Jenny Ostrowski',
    colour: cleanerColours.jenny.hex,
    photo: 'JO',
    role: 'Cleaner',
    phone: '07700 900 331',
    emergencyContact: 'Marek Ostrowski · 07700 900 332',
    availability: 'Tue–Sat, 8am–4pm',
    hoursThisWeek: 30,
    status: 'On Site',
    qcRating: 4.9,
  },
  {
    id: 'karolina',
    name: 'Karolina Nowak',
    colour: cleanerColours.karolina.hex,
    photo: 'KN',
    role: 'Cleaner',
    phone: '07700 900 441',
    emergencyContact: 'Piotr Nowak · 07700 900 442',
    availability: 'Mon–Fri, 9am–5pm',
    hoursThisWeek: 32,
    status: 'Available',
    qcRating: 4.6,
  },
  {
    id: 'vicki',
    name: 'Vicki Marsh',
    colour: cleanerColours.vicki.hex,
    photo: 'VM',
    role: 'Cleaner',
    phone: '07700 900 551',
    emergencyContact: 'Ian Marsh · 07700 900 552',
    availability: 'Wed–Sun, 8am–4pm',
    hoursThisWeek: 26,
    status: 'Finished',
    qcRating: 4.7,
  },
  {
    id: 'shamsun',
    name: 'Shamsun Nahar',
    colour: cleanerColours.shamsun.hex,
    photo: 'SN',
    role: 'Cleaner',
    phone: '07700 900 661',
    emergencyContact: 'Abdul Nahar · 07700 900 662',
    availability: 'Mon, Wed–Sat, 9am–5pm',
    hoursThisWeek: 28,
    status: 'Travelling',
    qcRating: 4.8,
  },
];

const staffIds = staff.map((s) => s.id);

export const clients = [
  {
    id: 'smith', name: 'Mrs. Eleanor Smith', address: '14 Larkspur Close, Richmond, TW9 2LH',
    phone: '020 7946 0891', email: 'eleanor.smith@email.co.uk', since: '2023', frequency: 'Fortnightly',
    cleaner: 'emma', balance: 0, properties: 1,
    notes: 'Labrador (Bramble) in the kitchen during visits. Side gate access, alarm not set. Extra attention to kitchen floor.',
    pets: 'Labrador — Bramble', alarmCode: 'Alarm not set — side gate code 4471', parking: 'Driveway, park left of the hedge',
    prefersEco: true,
    aiSummary: 'Mrs. Eleanor Smith has been a fortnightly customer since 2023. Emma usually attends. Recent visits indicate excellent cleanliness. Remember: Labrador in kitchen, side gate access, alarm not set, client prefers eco products.',
    upcoming: [{ date: '18 Jul', time: '10:00am', cleaner: 'emma' }, { date: '1 Aug', time: '10:00am', cleaner: 'emma' }],
    history: [
      { date: '4 Jul', cleaner: 'emma', status: 'Completed', qc: 'Pass' },
      { date: '20 Jun', cleaner: 'emma', status: 'Completed', qc: 'Pass' },
      { date: '6 Jun', cleaner: 'emma', status: 'Completed', qc: 'Pass' },
    ],
    invoices: [{ id: 'INV-2041', date: '4 Jul', amount: 78, status: 'Paid' }, { id: 'INV-2019', date: '20 Jun', amount: 78, status: 'Paid' }],
  },
  {
    id: 'harding', name: 'The Harding Family', address: '3 Cedar Grove, Kingston upon Thames, KT2 5JN',
    phone: '020 7946 1123', email: 'harding.family@email.co.uk', since: '2022', frequency: 'Weekly',
    cleaner: 'jenny', balance: 145, properties: 1,
    notes: 'Two children — playroom needs a toy pickup pass first. Shoes off past the hallway, slippers by the door.',
    pets: 'None', alarmCode: 'No alarm — key safe, code 8825', parking: 'Street parking, no permit before 10am',
    prefersEco: false,
    aiSummary: 'The Harding Family have had weekly visits since 2022, usually with Jenny. Recent QC flagged the playroom skirting boards. Remember: toy pickup pass first, shoes off past the hallway.',
    upcoming: [{ date: '15 Jul', time: '9:00am', cleaner: 'jenny' }, { date: '22 Jul', time: '9:00am', cleaner: 'jenny' }],
    history: [{ date: '8 Jul', cleaner: 'jenny', status: 'Completed', qc: 'Pass' }, { date: '1 Jul', cleaner: 'jenny', status: 'Completed', qc: 'Attention needed' }],
    invoices: [{ id: 'INV-2044', date: '8 Jul', amount: 145, status: 'Overdue' }],
  },
  {
    id: 'okafor', name: 'Mr. David Okafor', address: '27 Bellevue Terrace, Twickenham, TW1 3DF',
    phone: '020 7946 2290', email: 'd.okafor@email.co.uk', since: '2024', frequency: 'Monthly',
    cleaner: 'charlotte', balance: 0, properties: 2,
    notes: "Home office — avoid touching papers on the desk. Prefers the job wrapped up before 11am.",
    pets: 'None', alarmCode: '7729', parking: 'Garage — enter via side passage',
    prefersEco: false,
    aiSummary: 'Mr. Okafor has monthly visits since early 2024, with Charlotte attending personally. Home office on-site — desk left untouched. Prefers completion before 11am.',
    upcoming: [{ date: '2 Aug', time: '8:30am', cleaner: 'charlotte' }],
    history: [{ date: '5 Jul', cleaner: 'charlotte', status: 'Completed', qc: 'Pass' }, { date: '7 Jun', cleaner: 'charlotte', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2038', date: '5 Jul', amount: 110, status: 'Paid' }],
  },
  {
    id: 'ferreira', name: 'Ms. Camila Ferreira', address: '8 Orchard Rise, Surbiton, KT6 4NP',
    phone: '020 7946 3341', email: 'camila.ferreira@email.co.uk', since: '2021', frequency: 'Fortnightly',
    cleaner: 'karolina', balance: 82, properties: 1,
    notes: 'Cat (Miso) is shy — keep the utility room door shut. Uses her own eco products, stored under the sink.',
    pets: 'Cat — Miso, shy', alarmCode: '3390', parking: 'Off-street, one space by the bins',
    prefersEco: true,
    aiSummary: 'Ms. Ferreira has been fortnightly since 2021, with Karolina usually attending. A recent visit flagged streaks on the kitchen worktop. Remember: Miso the cat is shy, keep utility room shut, use her own eco products.',
    upcoming: [{ date: '19 Jul', time: '11:30am', cleaner: 'karolina' }],
    history: [{ date: '5 Jul', cleaner: 'karolina', status: 'Completed', qc: 'Attention needed' }, { date: '21 Jun', cleaner: 'karolina', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2040', date: '5 Jul', amount: 82, status: 'Overdue' }],
  },
  {
    id: 'nguyen', name: 'The Nguyen Household', address: '52 Willowmead Ave, New Malden, KT3 6RP',
    phone: '020 7946 4471', email: 'nguyen.household@email.co.uk', since: '2023', frequency: 'Weekly',
    cleaner: 'vicki', balance: 0, properties: 1,
    notes: 'An elderly parent stays in the annex — always knock first. Home is kept very tidy, so visits run light.',
    pets: 'None', alarmCode: 'None', parking: 'Driveway',
    prefersEco: false,
    aiSummary: 'The Nguyen Household have had weekly visits since 2023, with Vicki attending. An elderly relative stays in the annex — always knock before entering that side.',
    upcoming: [{ date: '16 Jul', time: '1:00pm', cleaner: 'vicki' }, { date: '23 Jul', time: '1:00pm', cleaner: 'vicki' }],
    history: [{ date: '9 Jul', cleaner: 'vicki', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2046', date: '9 Jul', amount: 65, status: 'Paid' }],
  },
  {
    id: 'ahmed', name: 'Dr. Farah Ahmed', address: '19 Meadowcroft Lane, Wimbledon, SW19 7QN',
    phone: '020 7946 5512', email: 'f.ahmed@email.co.uk', since: '2024', frequency: 'Weekly',
    cleaner: 'shamsun', balance: 0, properties: 1,
    notes: 'Works from home on Wednesdays — prefers a quieter clean that day. Fragrance-free products only.',
    pets: 'None', alarmCode: '2214', parking: 'Driveway',
    prefersEco: true,
    aiSummary: "Dr. Ahmed has had weekly visits since 2024, with Shamsun attending. Works from home on Wednesdays, so a quieter clean is appreciated. Fragrance-free products only.",
    upcoming: [{ date: '15 Jul', time: '2:00pm', cleaner: 'shamsun' }],
    history: [{ date: '8 Jul', cleaner: 'shamsun', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2049', date: '8 Jul', amount: 70, status: 'Paid' }],
  },
  {
    id: 'patel', name: 'The Patel Family', address: '61 Fairview Road, Sutton, SM1 4EJ',
    phone: '020 7946 6623', email: 'patel.family@email.co.uk', since: '2022', frequency: 'Fortnightly',
    cleaner: 'jenny', balance: 0, properties: 1,
    notes: 'Large family home, please focus on bathrooms and kitchen. Two cats — food left down, don\u2019t move bowls.',
    pets: 'Two cats', alarmCode: '5581', parking: 'Driveway, two cars',
    prefersEco: false,
    aiSummary: "The Patel Family are fortnightly clients since 2022, usually visited by Jenny. Two cats in the house — bowls should be left exactly where they are.",
    upcoming: [{ date: '17 Jul', time: '9:30am', cleaner: 'jenny' }],
    history: [{ date: '3 Jul', cleaner: 'jenny', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2035', date: '3 Jul', amount: 95, status: 'Paid' }],
  },
  {
    id: 'walsh', name: 'Mr. & Mrs. Walsh', address: '5 Primrose Terrace, Epsom, KT18 5RT',
    phone: '020 7946 7734', email: 'walsh.home@email.co.uk', since: '2025', frequency: 'Monthly',
    cleaner: 'vicki', balance: 60, properties: 1,
    notes: 'Retired couple, home most days — happy to chat but appreciates an efficient visit.',
    pets: 'None', alarmCode: 'None', parking: 'On street',
    prefersEco: false,
    aiSummary: 'The Walshes have had monthly visits since early 2025, with Vicki attending. A relaxed, efficient visit is appreciated — they\u2019re usually home.',
    upcoming: [{ date: '20 Jul', time: '10:30am', cleaner: 'vicki' }],
    history: [{ date: '20 Jun', cleaner: 'vicki', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2033', date: '20 Jun', amount: 60, status: 'Overdue' }],
  },
  {
    id: 'brennan', name: 'Ms. Isla Brennan', address: '102 Vale Road, Esher, KT10 9NT',
    phone: '020 7946 8845', email: 'isla.brennan@email.co.uk', since: '2024', frequency: 'One-off',
    cleaner: 'karolina', balance: 0, properties: 1,
    notes: 'End of tenancy clean ahead of a house sale — full checklist requested by the estate agent.',
    pets: 'None', alarmCode: 'None', parking: 'Driveway',
    prefersEco: false,
    aiSummary: 'Ms. Brennan booked a one-off end of tenancy clean, attended by Karolina and a second cleaner. Full checklist requested for the estate agent handover.',
    upcoming: [],
    history: [{ date: '10 Jul', cleaner: 'karolina', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2047', date: '10 Jul', amount: 240, status: 'Paid' }],
  },
  {
    id: 'russo', name: 'The Russo Household', address: '9 Chestnut Way, Chessington, KT9 1LB',
    phone: '020 7946 9956', email: 'russo.household@email.co.uk', since: '2023', frequency: 'Airbnb turnaround',
    cleaner: 'emma', balance: 0, properties: 1,
    notes: 'Short-let turnaround — tight window between guests. Linen change and restock included.',
    pets: 'None', alarmCode: 'Keybox 4420', parking: 'Residents\u2019 permit bay',
    prefersEco: false,
    aiSummary: 'The Russo property is an Airbnb, turned around between guests by Emma. Tight timing windows — linen change and restock are part of every visit.',
    upcoming: [{ date: '16 Jul', time: '11:00am', cleaner: 'emma' }],
    history: [{ date: '9 Jul', cleaner: 'emma', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2048', date: '9 Jul', amount: 90, status: 'Paid' }],
  },
  {
    id: 'obrien', name: 'The O\u2019Brien Family', address: '31 Riverbank Drive, Molesey, KT8 2PQ',
    phone: '020 7946 1187', email: 'obrien.family@email.co.uk', since: '2021', frequency: 'Weekly',
    cleaner: 'shamsun', balance: 0, properties: 1,
    notes: 'New baby in the house — please keep noise low during nap times, roughly 1–3pm.',
    pets: 'Dog — Poppy, friendly', alarmCode: '6690', parking: 'Driveway',
    prefersEco: true,
    aiSummary: 'The O\u2019Brien Family have weekly visits since 2021, with Shamsun attending. A new baby is in the house — keep noise low between 1 and 3pm.',
    upcoming: [{ date: '14 Jul', time: '9:00am', cleaner: 'shamsun' }],
    history: [{ date: '7 Jul', cleaner: 'shamsun', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2052', date: '7 Jul', amount: 72, status: 'Paid' }],
  },
  {
    id: 'fenwick', name: 'Mr. Charles Fenwick', address: '4 Abbey Court, Kingston upon Thames, KT1 2QW',
    phone: '020 7946 2298', email: 'c.fenwick@email.co.uk', since: '2020', frequency: 'Monthly',
    cleaner: 'charlotte', balance: 0, properties: 1,
    notes: 'Long-standing client, very particular about silverware polishing. Prefers Charlotte specifically.',
    pets: 'None', alarmCode: '1123', parking: 'Allocated bay, number 4',
    prefersEco: false,
    aiSummary: 'Mr. Fenwick has been a client since 2020 and specifically requests Charlotte. Particular about silverware polishing — worth double-checking before finishing.',
    upcoming: [{ date: '21 Jul', time: '9:00am', cleaner: 'charlotte' }],
    history: [{ date: '19 Jun', cleaner: 'charlotte', status: 'Completed', qc: 'Pass' }],
    invoices: [{ id: 'INV-2029', date: '19 Jun', amount: 130, status: 'Paid' }],
  },
];

// ---- Appointment generation --------------------------------------------
// Produces a realistically busy week (8–10 weekday visits, lighter weekend)
// with varied services, durations, start times, and occasional two-cleaner jobs.

const serviceCatalogue = [
  { name: 'Weekly Clean', duration: 90 },
  { name: 'Fortnightly Clean', duration: 90 },
  { name: 'Monthly Clean', duration: 120 },
  { name: 'Initial Assessment', duration: 45 },
  { name: 'Deep Clean', duration: 180, twoCleaners: true },
  { name: 'End of Tenancy', duration: 210, twoCleaners: true },
  { name: 'Airbnb Turnaround', duration: 75 },
  { name: 'Move In Clean', duration: 150 },
  { name: 'Post Renovation Clean', duration: 180, twoCleaners: true },
];

function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

function buildAppointments() {
  const rand = seededRandom(42);
  const dateMap = {
    '2026-07-13': 9, // Mon
    '2026-07-14': 9, // Tue (today)
    '2026-07-15': 8, // Wed
    '2026-07-16': 10, // Thu
    '2026-07-17': 8, // Fri
    '2026-07-18': 4, // Sat
    '2026-07-19': 1, // Sun
    '2026-08-02': 3, // next week sample, month view
  };
  const startHour = 8;
  const endHour = 17;
  const list = [];
  let counter = 1;

  Object.entries(dateMap).forEach(([date, count]) => {
    let cursor = startHour * 60; // minutes from midnight
    const span = (endHour - startHour) * 60;
    const gap = Math.max(20, Math.floor((span - count * 60) / count));

    for (let i = 0; i < count; i++) {
      const client = clients[Math.floor(rand() * clients.length)];
      const service = serviceCatalogue[Math.floor(rand() * serviceCatalogue.length)];
      const primary = client.cleaner;
      let secondary = null;
      if (service.twoCleaners) {
        const others = staffIds.filter((id) => id !== primary);
        secondary = others[Math.floor(rand() * others.length)];
      }

      const hour = Math.floor(cursor / 60);
      const minute = cursor % 60 < 30 ? 0 : 30;
      const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
      cursor += service.duration * 0.5 + gap; // stagger, allow slight overlap across cleaners

      const statusPool = date < TODAY ? ['Completed'] : date === TODAY ? ['Completed', 'In Progress', 'Scheduled'] : ['Scheduled'];
      const status = statusPool[Math.floor(rand() * statusPool.length)];

      list.push({
        id: `apt-${counter++}`,
        clientId: client.id,
        client: client.name,
        phone: client.phone,
        address: client.address,
        date,
        time,
        duration: service.duration,
        cleaner: primary,
        secondaryCleaner: secondary,
        service: service.name,
        status,
      });
    }
  });

  return list.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
}

export const appointments = buildAppointments();

export const qualityChecks = [
  { id: 'qc1', clientId: 'harding', client: 'The Harding Family', cleaner: 'jenny', date: '1 Jul', status: 'Attention needed', comment: 'Skirting boards missed in the playroom — flagged to revisit next visit.' },
  { id: 'qc2', clientId: 'ferreira', client: 'Ms. Camila Ferreira', cleaner: 'karolina', date: '5 Jul', status: 'Attention needed', comment: 'Kitchen worktop streaks left near the window. Karolina notified.' },
  { id: 'qc3', clientId: 'smith', client: 'Mrs. Eleanor Smith', cleaner: 'emma', date: '4 Jul', status: 'Pass', comment: 'Spotless, as usual. Kitchen floor specifically checked.' },
  { id: 'qc4', clientId: 'nguyen', client: 'The Nguyen Household', cleaner: 'vicki', date: '9 Jul', status: 'Pass', comment: 'Quick, tidy visit — no issues.' },
  { id: 'qc5', clientId: 'okafor', client: 'Mr. David Okafor', cleaner: 'charlotte', date: '5 Jul', status: 'Pass', comment: 'Office left undisturbed as requested.' },
  { id: 'qc6', clientId: 'walsh', client: 'Mr. & Mrs. Walsh', cleaner: 'vicki', date: '20 Jun', status: 'Pending', comment: 'Awaiting supervisor sign-off on first monthly visit.' },
];

export const invoices = [
  { id: 'INV-2046', client: 'The Nguyen Household', clientId: 'nguyen', date: '9 Jul 2026', amount: 65, status: 'Paid' },
  { id: 'INV-2044', client: 'The Harding Family', clientId: 'harding', date: '8 Jul 2026', amount: 145, status: 'Overdue' },
  { id: 'INV-2041', client: 'Mrs. Eleanor Smith', clientId: 'smith', date: '4 Jul 2026', amount: 78, status: 'Paid' },
  { id: 'INV-2040', client: 'Ms. Camila Ferreira', clientId: 'ferreira', date: '5 Jul 2026', amount: 82, status: 'Overdue' },
  { id: 'INV-2038', client: 'Mr. David Okafor', clientId: 'okafor', date: '5 Jul 2026', amount: 110, status: 'Paid' },
  { id: 'INV-2050', client: 'Mrs. Eleanor Smith', clientId: 'smith', date: '18 Jul 2026', amount: 78, status: 'Draft' },
  { id: 'INV-2033', client: 'Mr. & Mrs. Walsh', clientId: 'walsh', date: '20 Jun 2026', amount: 60, status: 'Overdue' },
  { id: 'INV-2047', client: 'Ms. Isla Brennan', clientId: 'brennan', date: '10 Jul 2026', amount: 240, status: 'Paid' },
];

export const messages = [
  { id: 'm1', author: 'Emma Whitlock', time: '8:42am', text: 'Running 15 minutes late to the Hardings — traffic on the A308.' },
  { id: 'm2', author: 'System', time: '8:15am', text: 'QC flagged for Camila Ferreira — Karolina notified, revisit scheduled.' },
  { id: 'm3', author: 'Charlotte Kebble', time: 'Yesterday', text: 'Okafor job done, all good. Office left exactly as it was.' },
  { id: 'm4', author: 'System', time: 'Yesterday', text: 'Invoice INV-2044 is now 6 days overdue — Harding Family.' },
  { id: 'm5', author: 'Jenny Ostrowski', time: '2 days ago', text: 'Bramble was extra friendly today, Eleanor sends her thanks!' },
  { id: 'm6', author: 'System', time: '2 days ago', text: 'New client added — Mr. Charles Fenwick, monthly clean.' },
];

export const reports = {
  appointmentsThisWeek: [
    { day: 'Mon', count: 9 }, { day: 'Tue', count: 9 }, { day: 'Wed', count: 8 },
    { day: 'Thu', count: 10 }, { day: 'Fri', count: 8 }, { day: 'Sat', count: 4 }, { day: 'Sun', count: 1 },
  ],
  revenueByMonth: [
    { month: 'Feb', revenue: 8200 }, { month: 'Mar', revenue: 8550 }, { month: 'Apr', revenue: 8900 },
    { month: 'May', revenue: 9280 }, { month: 'Jun', revenue: 9620 }, { month: 'Jul', revenue: 7460 },
  ],
  cleanerUtilisation: [
    { name: 'Charlotte', pct: 91 }, { name: 'Emma', pct: 94 }, { name: 'Jenny', pct: 86 },
    { name: 'Karolina', pct: 82 }, { name: 'Vicki', pct: 74 }, { name: 'Shamsun', pct: 79 },
  ],
  recurringCustomers: 46,
  totalCustomers: 52,
  cancellationRate: 2.8,
  qcPassRate: 92,
};

export function getKpis() {
  const todays = appointments.filter((a) => a.date === TODAY);
  const workingToday = new Set(todays.flatMap((a) => [a.cleaner, a.secondaryCleaner].filter(Boolean)));
  return {
    todaysAppointments: todays.length,
    staffWorking: workingToday.size,
    jobsCompleted: todays.filter((a) => a.status === 'Completed').length,
    outstandingInvoices: invoices.filter((i) => i.status === 'Overdue').length,
    pendingQC: qualityChecks.filter((q) => q.status === 'Pending' || q.status === 'Attention needed').length,
    upcomingThisWeek: appointments.filter((a) => a.date >= '2026-07-13' && a.date <= '2026-07-19').length,
  };
}

export const kpis = getKpis();
