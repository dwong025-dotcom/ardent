import { useEffect, useState } from 'react';
import { Phone, Clock, Star, MapPin } from 'lucide-react';
import { TODAY, NOW_MINUTES, clients } from '../data/mockData';
import { fetchStaff, fetchAppointments } from '../data/source';
import { Card, SectionHeading, StatusPill } from '../components/ui';

function minutesOf(time) {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export default function Staff() {
  const [staff, setStaff] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([fetchStaff(), fetchAppointments()])
      .then(([staffData, apptData]) => {
        if (cancelled) return;
        setStaff(staffData);
        setAppointments(apptData);
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, []);

  const todaysAppts = appointments.filter((a) => a.date === TODAY);

  if (loading) {
    return <div className="text-sm text-charcoal-soft py-10 text-center">Loading staff…</div>;
  }

  return (
    <div className="space-y-6">
      <SectionHeading eyebrow="Team" title="Staff" />

      {error && (
        <div className="text-sm text-status-red bg-status-red-bg rounded-2xl px-4 py-3">
          Couldn't load live staff data: {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {staff.map((s) => {
          const mine = todaysAppts.filter((a) => a.cleaner === s.id || a.secondaryCleaner === s.id);
          const upcoming = mine.filter((a) => minutesOf(a.time) >= NOW_MINUTES).sort((a, b) => a.time.localeCompare(b.time));
          const next = upcoming[0];
          const nextClient = next ? clients.find((c) => c.id === next.clientId) : null;
          const hoursScheduled = (mine.reduce((sum, a) => sum + (a.duration || 0), 0) / 60).toFixed(1);

          return (
            <Card key={s.id} className="p-6">
              <div className="flex items-center gap-4 mb-5">
                <div
                  className="w-14 h-14 rounded-full flex items-center justify-center text-white font-display text-lg shrink-0"
                  style={{ backgroundColor: s.colour }}
                >
                  {s.photo}
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-display text-lg text-charcoal leading-tight truncate">{s.name}</h3>
                  <div className="text-sm text-charcoal-soft">{s.role}</div>
                </div>
                <StatusPill status={s.status} />
              </div>

              <div className="bg-warmwhite rounded-2xl p-3.5 mb-4">
                <div className="text-[11px] uppercase tracking-wide text-charcoal-soft mb-1.5">Next appointment</div>
                {next ? (
                  <div>
                    <div className="text-sm text-charcoal font-medium font-mono">{next.time}</div>
                    <div className="text-sm text-charcoal">{nextClient?.name || next.client}</div>
                    <div className="flex items-center gap-1 text-xs text-charcoal-soft mt-0.5">
                      <MapPin size={11} />
                      {(nextClient?.address || next.address)?.split(',').slice(-2, -1)[0]?.trim()}
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-charcoal-soft">No further visits scheduled today</div>
                )}
              </div>

              <div className="space-y-2 text-sm mb-4">
                <div className="flex items-center gap-2.5 text-charcoal-soft">
                  <Clock size={14} /> {s.availability}
                </div>
                <div className="flex items-center gap-2.5 text-charcoal-soft">
                  <Phone size={14} /> {s.phone}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 mb-4">
                <Stat label="Today's jobs" value={mine.length} />
                <Stat label="Hrs scheduled" value={hoursScheduled} />
                <Stat label="Hrs/wk" value={s.hoursThisWeek ?? '—'} />
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-black/[0.05]">
                <div className="flex items-center gap-1.5 text-sm text-charcoal">
                  <Star size={14} className="text-gold fill-gold" /> QC rating {s.qcRating ?? '—'}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="bg-warmwhite rounded-xl py-2 text-center">
      <div className="font-display text-lg text-charcoal">{value}</div>
      <div className="text-[10px] text-charcoal-soft uppercase tracking-wide leading-tight">{label}</div>
    </div>
  );
}
