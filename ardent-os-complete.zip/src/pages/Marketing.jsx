import { Link } from 'react-router-dom';
import { Calendar, ShieldCheck, Receipt, ArrowRight, Check } from 'lucide-react';

const features = [
  {
    icon: Calendar,
    title: 'A calendar that feels calm',
    body: "Every cleaner has their own colour, every visit its own card. Charlotte can see her whole week without squinting.",
  },
  {
    icon: ShieldCheck,
    title: 'Quality control, built in',
    body: 'Before-and-after photos and a pass/attention flag on every visit — no separate app, no chasing.',
  },
  {
    icon: Receipt,
    title: 'Invoicing that stays on top of you',
    body: 'Draft, sent, paid, overdue — always visible, always one click from being chased up.',
  },
];

export default function Marketing() {
  return (
    <div className="min-h-screen bg-warmwhite text-charcoal">
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div>
          <div className="font-display text-xl leading-tight">Ardent OS</div>
          <div className="text-[11px] text-charcoal-soft">Business Operating System</div>
        </div>
        <Link to="/" className="text-sm px-4 py-2 rounded-xl border border-black/10 hover:border-teal/40 transition-colors">
          View demo
        </Link>
      </header>

      <section className="max-w-4xl mx-auto px-6 pt-16 pb-20 text-center">
        <div className="text-xs uppercase tracking-[0.2em] text-teal font-medium mb-6">Built for Ardent Cleaning &amp; Ardent Living</div>
        <h1 className="font-display text-4xl md:text-6xl leading-[1.08] tracking-tight">
          Your cleaning business deserves better than generic software.
        </h1>
        <p className="text-lg text-charcoal-soft mt-6 max-w-2xl mx-auto leading-relaxed">
          Ardent OS is a bespoke operating system built specifically around how your business works —
          not how software expects you to work.
        </p>
        <div className="flex items-center justify-center gap-3 mt-9 flex-wrap">
          <Link to="/" className="bg-teal text-white px-6 py-3 rounded-xl text-sm hover:bg-teal-dark transition-colors flex items-center gap-2">
            View Demo <ArrowRight size={15} />
          </Link>
          <a href="#contact" className="border border-black/10 px-6 py-3 rounded-xl text-sm hover:border-teal/40 transition-colors">
            Book a Discovery Call
          </a>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map(({ icon: Icon, title, body }) => (
            <div key={title} className="bg-card rounded-2xl border border-black/[0.05] p-7 shadow-[var(--shadow-card)]">
              <div className="w-10 h-10 rounded-xl bg-teal-light flex items-center justify-center text-teal mb-5">
                <Icon size={19} strokeWidth={1.75} />
              </div>
              <h3 className="font-display text-lg mb-2">{title}</h3>
              <p className="text-sm text-charcoal-soft leading-relaxed">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-6 pb-24">
        <div className="bg-charcoal rounded-3xl p-10 md:p-14 text-warmwhite">
          <div className="text-xs uppercase tracking-[0.2em] text-gold font-medium mb-4">If ZenMaid shows 15 things</div>
          <h2 className="font-display text-3xl md:text-4xl leading-tight mb-6">We show you the 5 that matter today.</h2>
          <ul className="space-y-3 mb-8">
            {['Fewer screens, more clarity', 'One calm dashboard instead of fifteen alerts', 'Built around Ardent — not retrofitted from someone else\'s workflow'].map((t) => (
              <li key={t} className="flex items-start gap-3 text-warmwhite/85">
                <Check size={16} className="text-gold mt-1 shrink-0" /> {t}
              </li>
            ))}
          </ul>
          <a href="#contact" className="inline-flex items-center gap-2 bg-gold text-charcoal px-6 py-3 rounded-xl text-sm font-medium hover:brightness-95 transition-all">
            Book a Discovery Call <ArrowRight size={15} />
          </a>
        </div>
      </section>

      <footer id="contact" className="border-t border-black/[0.06] py-10 text-center text-sm text-charcoal-soft">
        Ardent OS — powered by Simputic · hello@simputic.com
      </footer>
    </div>
  );
}
