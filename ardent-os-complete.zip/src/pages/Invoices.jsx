import { useState } from 'react';
import { Send, Link2 } from 'lucide-react';
import { invoices } from '../data/mockData';
import { Card, SectionHeading, StatusPill } from '../components/ui';

const tabs = ['All', 'Outstanding', 'Paid', 'Draft', 'Overdue'];

export default function Invoices() {
  const [tab, setTab] = useState('All');

  const filtered = invoices.filter((inv) => {
    if (tab === 'All') return true;
    if (tab === 'Outstanding') return inv.status === 'Overdue' || inv.status === 'Draft';
    return inv.status === tab;
  });

  const totals = {
    outstanding: invoices.filter((i) => i.status === 'Overdue').reduce((s, i) => s + i.amount, 0),
    paid: invoices.filter((i) => i.status === 'Paid').reduce((s, i) => s + i.amount, 0),
    draft: invoices.filter((i) => i.status === 'Draft').reduce((s, i) => s + i.amount, 0),
  };

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Billing"
        title="Invoices"
        action={
          <div className="flex items-center gap-2 text-xs text-charcoal-soft bg-sage-light px-3 py-1.5 rounded-xl">
            <Link2 size={13} /> Connected to Xero
          </div>
        }
      />

      <div className="grid grid-cols-3 gap-4 max-w-xl">
        <Card className="p-4 text-center">
          <div className="font-display text-2xl text-status-red">£{totals.outstanding}</div>
          <div className="text-xs text-charcoal-soft mt-0.5">Overdue</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="font-display text-2xl text-status-green">£{totals.paid}</div>
          <div className="text-xs text-charcoal-soft mt-0.5">Paid</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="font-display text-2xl text-status-blue">£{totals.draft}</div>
          <div className="text-xs text-charcoal-soft mt-0.5">Draft</div>
        </Card>
      </div>

      <div className="flex items-center gap-1 bg-sage-light rounded-2xl p-1 w-fit">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-3.5 py-1.5 rounded-xl text-sm transition-colors ${
              tab === t ? 'bg-white text-charcoal shadow-sm' : 'text-charcoal-soft'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-black/[0.05] text-left text-xs text-charcoal-soft uppercase tracking-wide">
              <th className="px-5 py-3 font-medium">Invoice</th>
              <th className="px-5 py-3 font-medium">Client</th>
              <th className="px-5 py-3 font-medium">Date</th>
              <th className="px-5 py-3 font-medium">Amount</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((inv) => (
              <tr key={inv.id} className="border-b border-black/[0.04] last:border-0 hover:bg-warmwhite/60 transition-colors">
                <td className="px-5 py-3 font-mono text-charcoal">{inv.id}</td>
                <td className="px-5 py-3 text-charcoal">{inv.client}</td>
                <td className="px-5 py-3 text-charcoal-soft">{inv.date}</td>
                <td className="px-5 py-3 text-charcoal">£{inv.amount}</td>
                <td className="px-5 py-3"><StatusPill status={inv.status} /></td>
                <td className="px-5 py-3 text-right">
                  <button className="inline-flex items-center gap-1.5 text-teal text-sm hover:gap-2 transition-all">
                    <Send size={13} /> Send
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
