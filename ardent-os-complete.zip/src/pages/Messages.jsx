import { Bell, MessageCircle } from 'lucide-react';
import { messages } from '../data/mockData';
import { Card, SectionHeading } from '../components/ui';

export default function Messages() {
  return (
    <div className="space-y-6">
      <SectionHeading eyebrow="Inbox" title="Messages" />

      <Card className="divide-y divide-black/[0.05]">
        {messages.map((m) => (
          <div key={m.id} className="flex items-start gap-4 p-5">
            <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
              m.author === 'System' ? 'bg-status-amber-bg text-status-amber' : 'bg-teal-light text-teal'
            }`}>
              {m.author === 'System' ? <Bell size={16} /> : <MessageCircle size={16} />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-charcoal">{m.author}</span>
                <span className="text-xs text-charcoal-soft shrink-0">{m.time}</span>
              </div>
              <p className="text-sm text-charcoal-soft mt-0.5 leading-snug">{m.text}</p>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}
