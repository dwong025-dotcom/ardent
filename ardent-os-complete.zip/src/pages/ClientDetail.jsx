import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Phone, Mail, PawPrint, KeyRound, Car } from 'lucide-react';
import { clients } from '../data/mockData';
import { Card, CleanerTag, FieldNote, StatusPill } from '../components/ui';

export default function ClientDetail() {
  const { id } = useParams();
  const client = clients.find((c) => c.id === id);

  if (!client) {
    return (
      <div className="text-center py-20 text-charcoal-soft">
        Client not found. <Link to="/clients" className="text-teal">Back to clients</Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Link to="/clients" className="inline-flex items-center gap-1.5 text-sm text-charcoal-soft hover:text-teal transition-colors">
        <ArrowLeft size={15} /> Back to clients
      </Link>

      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl text-charcoal">{client.name}</h1>
          <div className="flex items-center gap-1.5 text-charcoal-soft mt-1.5">
            <MapPin size={15} /> {client.address}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <CleanerTag id={client.cleaner} />
          <span className="text-sm text-charcoal-soft">·</span>
          <span className="text-sm text-charcoal-soft">{client.frequency}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <FieldNote>{client.aiSummary}</FieldNote>

          <Card className="p-6">
            <h2 className="font-display text-xl text-charcoal mb-4">Upcoming appointments</h2>
            <div className="space-y-2">
              {client.upcoming.map((u, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-warmwhite">
                  <span className="text-sm text-charcoal">{u.date} · {u.time}</span>
                  <CleanerTag id={u.cleaner} />
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="font-display text-xl text-charcoal mb-4">Visit history</h2>
            <div className="space-y-2">
              {client.history.map((h, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-warmwhite">
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-charcoal">{h.date}</span>
                    <CleanerTag id={h.cleaner} />
                  </div>
                  <StatusPill status={h.qc} />
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="font-display text-xl text-charcoal mb-4">Invoices</h2>
            <div className="space-y-2">
              {client.invoices.map((inv) => (
                <div key={inv.id} className="flex items-center justify-between p-3 rounded-xl bg-warmwhite">
                  <div>
                    <span className="text-sm font-mono text-charcoal">{inv.id}</span>
                    <span className="text-xs text-charcoal-soft ml-2">{inv.date}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-charcoal">£{inv.amount}</span>
                    <StatusPill status={inv.status} />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="font-display text-lg text-charcoal mb-4">Contact</h2>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2.5 text-charcoal"><Phone size={15} className="text-charcoal-soft" /> {client.phone}</div>
              <div className="flex items-center gap-2.5 text-charcoal"><Mail size={15} className="text-charcoal-soft" /> {client.email}</div>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="font-display text-lg text-charcoal mb-4">Property details</h2>
            <div className="space-y-3">
              <InfoRow icon={PawPrint} label="Pets" value={client.pets} />
              <InfoRow icon={KeyRound} label="Access" value={client.alarmCode} />
              <InfoRow icon={Car} label="Parking" value={client.parking} />
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="font-display text-lg text-charcoal mb-3">Notes</h2>
            <p className="text-sm text-charcoal-soft leading-relaxed">{client.notes}</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between text-sm">
              <span className="text-charcoal-soft">Outstanding balance</span>
              <span className={`font-display text-lg ${client.balance > 0 ? 'text-status-red' : 'text-status-green'}`}>
                £{client.balance}
              </span>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 text-xs text-charcoal-soft mb-0.5">
        <Icon size={13} /> {label}
      </div>
      <div className="text-sm text-charcoal">{value}</div>
    </div>
  );
}
