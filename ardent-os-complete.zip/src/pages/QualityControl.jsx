import { useState } from 'react';
import { ImageOff, ShieldCheck } from 'lucide-react';
import { qualityChecks, staff, clients } from '../data/mockData';
import { Card, CleanerTag, SectionHeading, StatusPill, EmptyState } from '../components/ui';

export default function QualityControl() {
  const [cleanerFilter, setCleanerFilter] = useState('all');
  const [clientFilter, setClientFilter] = useState('all');

  const filtered = qualityChecks.filter((q) => {
    const okCleaner = cleanerFilter === 'all' || q.cleaner === cleanerFilter;
    const okClient = clientFilter === 'all' || q.clientId === clientFilter;
    return okCleaner && okClient;
  });

  return (
    <div className="space-y-6">
      <SectionHeading eyebrow="Standards" title="Quality Control" />

      <div className="flex items-center gap-3 flex-wrap">
        <select
          value={cleanerFilter}
          onChange={(e) => setCleanerFilter(e.target.value)}
          className="bg-white border border-black/[0.06] rounded-xl px-3 py-2 text-sm text-charcoal"
        >
          <option value="all">All cleaners</option>
          {staff.map((s) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </select>
        <select
          value={clientFilter}
          onChange={(e) => setClientFilter(e.target.value)}
          className="bg-white border border-black/[0.06] rounded-xl px-3 py-2 text-sm text-charcoal"
        >
          <option value="all">All clients</option>
          {clients.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((q) => (
          <Card key={q.id} className="overflow-hidden">
            <div className="grid grid-cols-2">
              <div className="aspect-[4/3] bg-sage-light flex flex-col items-center justify-center text-charcoal-soft/60 border-r border-black/[0.05]">
                <ImageOff size={22} />
                <span className="text-[11px] mt-1">Before</span>
              </div>
              <div className="aspect-[4/3] bg-teal-light flex flex-col items-center justify-center text-teal-dark/50">
                <ImageOff size={22} />
                <span className="text-[11px] mt-1">After</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-charcoal font-medium">{q.client}</span>
                <StatusPill status={q.status} />
              </div>
              <div className="flex items-center justify-between text-xs text-charcoal-soft mb-2">
                <CleanerTag id={q.cleaner} />
                <span>{q.date}</span>
              </div>
              <p className="text-sm text-charcoal-soft leading-snug">{q.comment}</p>
            </div>
          </Card>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full">
            <Card><EmptyState icon={ShieldCheck} title="No quality checks match this filter" body="Try a different cleaner or client, or clear the filters above." /></Card>
          </div>
        )}
      </div>
    </div>
  );
}
