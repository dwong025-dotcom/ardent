import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarClock, Users, CheckCircle2, Receipt, ShieldAlert, CalendarDays, ArrowRight, CalendarPlus, UserPlus, FileText, ClipboardCheck, UserCog, Send } from 'lucide-react';
import { Card, CleanerAvatarStack, EmptyState } from '../components/ui';
import { messages, TODAY, qualityChecks, invoices } from '../data/mockData';
import { fetchStaff, fetchAppointments } from '../data/source';

const toneClasses = {
  teal: 'bg-teal-light text-teal',
  amber: 'bg-status-amber-bg text-status-amber',
  sage: 'bg-sage-light text-teal-dark',
};

const quickActions = [
  { label: 'Create Appointment', to: '/calendar', icon: CalendarPlus },
  { label: 'New Client', to: '/clients', icon: UserPlus },
  { label: 'Generate Invoice', to: '/invoices', icon: FileText },
  { label: 'Review QC', to: '/quality-control', icon: ClipboardCheck },
  { label: 'Assign Cleaner', to: '/staff', icon: UserCog },
  { label: 'Send Customer Update', to: '/messages', icon: Send },
];

export default function Dashboard() {
  const [staff, setStaff] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([fetchStaff(), fetchAppointments()])
      .then(([staffData, apptData]) => {
        if (cancelled) return;
        setStaff(staffData);
        setAppointments(apptData);
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, []);

  const today = appointments
    .filter((a) => a.date === TODAY)
    .sort((a, b) => a.time.localeCompare(b.time));

  const overdueCount = invoices.filter((i) => i.status === 'Overdue').length;
  const pendingQCCount = qualityChecks.filter((q) => q.status === 'Pending' || q.status === 'Attention needed').length;
  const workingCount = new Set(today.flatMap((a) => [a.cleaner, a.secondaryCleaner].filter(Boolean))).size;
  const upcomingThisWeek = appointments.filter((a) => a.date >= '2026-07-13' && a.date <= '2026-07-19').length;

  const kpiCards = [
    { label: "Today's Appointments", value: today.length, icon: CalendarClock, tone: 'teal' },
    { label: 'Cleaners Working', value: workingCount, icon: Users, tone: 'sage' },
    { label: 'Jobs Completed Today', value: today.filter((a) => a.status === 'Completed').length, icon: CheckCircle2, tone: 'teal' },
    { label: 'Outstanding Invoices', value: overdueCount, icon: Receipt, tone: 'amber' },
    { label: 'QC Reviews Waiting', value: pendingQCCount, icon: ShieldAlert, tone: 'amber' },
    { label: 'Visits This Week', value: upcomingThisWeek, icon: CalendarDays, tone: 'sage' },
  ];

  if (loading) {
    return <div className="text-sm text-charcoal-soft py-10 text-center">Loading dashboard…</div>;
  }

  return (
    <div className="space-y-8">
      {error && (
        <div className="text-sm text-status-red bg-status-red-bg rounded-2xl px-4 py-3">
          Couldn't load live schedule data: {error}
        </div>
      )}

      <div>
        <h1 className="font-display text-3xl text-charcoal">Good morning Charlotte 👋</h1>
        <p className="text-charcoal-soft mt-1">Welcome back to Ardent OS.</p>
        <p className="text-sm text-charcoal-soft mt-3 bg-sage-light/60 rounded-xl px-4 py-2.5 inline-block leading-relaxed">
          You have <span className="text-charcoal font-medium">{today.length} appointments</span> today across{' '}
          <span className="text-charcoal font-medium">{workingCount} cleaners</span>.{' '}
          <span className="text-charcoal font-medium">{overdueCount} invoice{overdueCount === 1 ? '' : 's'}</span> require attention.{' '}
          <span className="text-charcoal font-medium">{pendingQCCount} quality check{pendingQCCount === 1 ? '' : 's'}</span>{' '}
          awaiting approval.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {kpiCards.map(({ label, value, icon: Icon, tone }) => (
          <Card key={label} className="p-5 hover:-translate-y-0.5 transition-transform">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-4 ${toneClasses[tone]}`}>
              <Icon size={17} strokeWidth={1.75} />
            </div>
            <div className="font-display text-3xl text-charcoal">{value}</div>
            <div className="text-xs text-charcoal-soft mt-1 leading-snug">{label}</div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-xl text-charcoal">Today's schedule</h2>
            <Link to="/calendar" className="text-sm text-teal flex items-center gap-1 hover:gap-1.5 transition-all">
              Open calendar <ArrowRight size={14} />
            </Link>
          </div>
          {today.length === 0 ? (
            <EmptyState title="No appointments today" body="Enjoy the quiet — nothing is scheduled for today yet." />
          ) : (
            <div className="space-y-1">
              {today.map((a) => (
                <Link
                  key={a.id}
                  to={`/clients/${a.clientId}`}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-sage-light/60 transition-colors group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-14 text-sm font-mono text-charcoal-soft shrink-0">{a.time}</div>
                    <div className="min-w-0">
                      <div className="text-[15px] text-charcoal truncate">{a.client}</div>
                      <div className="text-xs text-charcoal-soft truncate">{a.service}</div>
                    </div>
                  </div>
                  <CleanerAvatarStack primary={a.cleaner} secondary={a.secondaryCleaner} />
                </Link>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-6">
          <h2 className="font-display text-xl text-charcoal mb-4">Recent updates</h2>
          <div className="space-y-4">
            {messages.slice(0, 4).map((m) => (
              <div key={m.id} className="text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-charcoal font-medium">{m.author}</span>
                  <span className="text-xs text-charcoal-soft">{m.time}</span>
                </div>
                <p className="text-charcoal-soft mt-0.5 leading-snug">{m.text}</p>
              </div>
            ))}
          </div>
          <Link to="/messages" className="text-sm text-teal flex items-center gap-1 mt-4 hover:gap-1.5 transition-all">
            View all messages <ArrowRight size={14} />
          </Link>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="p-6">
          <h2 className="font-display text-xl text-charcoal mb-4">Cleaners working today</h2>
          <div className="space-y-3">
            {staff.slice(0, 5).map((s) => {
              const jobsToday = today.filter((a) => a.cleaner === s.id || a.secondaryCleaner === s.id).length;
              return (
                <div key={s.id} className="flex items-center gap-3">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-medium shrink-0"
                    style={{ backgroundColor: s.colour }}
                  >
                    {s.photo}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-charcoal truncate">{s.name}</div>
                    <div className="text-xs text-charcoal-soft">{jobsToday} job{jobsToday === 1 ? '' : 's'} today</div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="lg:col-span-2 p-6">
          <h2 className="font-display text-xl text-charcoal mb-4">Quick actions</h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map(({ label, to, icon: Icon }) => (
              <Link
                key={label}
                to={to}
                className="flex items-center gap-2.5 p-4 rounded-2xl border border-black/[0.05] hover:border-teal/30 hover:bg-teal-light/40 hover:-translate-y-0.5 transition-all text-sm text-charcoal"
              >
                <Icon size={16} className="text-teal shrink-0" />
                {label}
              </Link>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
