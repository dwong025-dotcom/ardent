import {
  ResponsiveContainer, BarChart, Bar, LineChart, Line, XAxis, YAxis,
  Tooltip, CartesianGrid,
} from 'recharts';
import { reports } from '../data/mockData';
import { Card, SectionHeading } from '../components/ui';

const teal = '#0F766E';
const gold = '#C9A24B';

export default function Reports() {
  const cancellationLabel = `${reports.cancellationRate}%`;
  const qcLabel = `${reports.qcPassRate}%`;

  return (
    <div className="space-y-6">
      <SectionHeading eyebrow="Insight" title="Reports" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Recurring customers" value={`${reports.recurringCustomers}/${reports.totalCustomers}`} />
        <Stat label="Cancellation rate" value={cancellationLabel} />
        <Stat label="QC pass rate" value={qcLabel} />
        <Stat label="Appointments this week" value={reports.appointmentsThisWeek.reduce((s, d) => s + d.count, 0)} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="font-display text-lg text-charcoal mb-4">Appointments this week</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={reports.appointmentsThisWeek}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EDE8DE" />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#625E58' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#625E58' }} axisLine={false} tickLine={false} width={24} />
              <Tooltip cursor={{ fill: '#F6EFDE' }} contentStyle={{ borderRadius: 10, border: '1px solid #eee', fontSize: 13 }} />
              <Bar dataKey="count" fill={teal} radius={[6, 6, 0, 0]} maxBarSize={36} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6">
          <h2 className="font-display text-lg text-charcoal mb-4">Revenue</h2>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={reports.revenueByMonth}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EDE8DE" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#625E58' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#625E58' }} axisLine={false} tickLine={false} width={40} tickFormatter={(v) => `£${v}`} />
              <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid #eee', fontSize: 13 }} formatter={(v) => [`£${v}`, 'Revenue']} />
              <Line type="monotone" dataKey="revenue" stroke={gold} strokeWidth={2.5} dot={{ r: 3, fill: gold }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <h2 className="font-display text-lg text-charcoal mb-4">Cleaner utilisation</h2>
          <div className="space-y-3">
            {reports.cleanerUtilisation.map((c) => (
              <div key={c.name} className="flex items-center gap-4">
                <div className="w-16 text-sm text-charcoal">{c.name}</div>
                <div className="flex-1 h-2.5 bg-sage-light rounded-full overflow-hidden">
                  <div className="h-full bg-teal rounded-full" style={{ width: `${c.pct}%` }} />
                </div>
                <div className="w-10 text-sm text-charcoal-soft text-right">{c.pct}%</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <Card className="p-5">
      <div className="font-display text-2xl text-charcoal">{value}</div>
      <div className="text-xs text-charcoal-soft mt-1">{label}</div>
    </Card>
  );
}
