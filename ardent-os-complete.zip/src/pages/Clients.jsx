import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, ArrowRight, Users } from 'lucide-react';
import { clients } from '../data/mockData';
import { Card, CleanerTag, SectionHeading, EmptyState } from '../components/ui';

export default function Clients() {
  const [query, setQuery] = useState('');
  const filtered = clients.filter((c) =>
    (c.name + c.address).toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <SectionHeading eyebrow="Book of business" title="Clients" />

      <div className="relative max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal-soft" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by name or address…"
          className="w-full bg-white border border-black/[0.06] rounded-xl pl-9 pr-3 py-2.5 text-sm focus:border-teal/40 transition-colors"
        />
      </div>

      {filtered.length === 0 ? (
        <Card><EmptyState icon={Users} title="No clients match your search" body="Try a different name or address, or clear the search to see everyone." /></Card>
      ) : (
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((c) => (
          <Link key={c.id} to={`/clients/${c.id}`}>
            <Card className="p-5 h-full hover:-translate-y-0.5 hover:shadow-[0_18px_44px_-14px_rgba(43,41,38,0.18)] transition-all duration-200">
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-display text-lg text-charcoal leading-tight">{c.name}</h3>
                {c.balance > 0 && (
                  <span className="text-xs text-status-red bg-status-red-bg px-2 py-0.5 rounded-full shrink-0">
                    £{c.balance} due
                  </span>
                )}
              </div>
              <div className="flex items-start gap-1.5 text-sm text-charcoal-soft mb-3">
                <MapPin size={14} className="mt-0.5 shrink-0" />
                <span>{c.address}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <CleanerTag id={c.cleaner} />
                <span className="text-charcoal-soft">{c.frequency}</span>
              </div>
              <div className="mt-4 pt-4 border-t border-black/[0.05] flex items-center justify-between text-sm">
                <span className="text-charcoal-soft">Client since {c.since}</span>
                <ArrowRight size={14} className="text-teal" />
              </div>
            </Card>
          </Link>
        ))}
      </div>
      )}
    </div>
  );
}
