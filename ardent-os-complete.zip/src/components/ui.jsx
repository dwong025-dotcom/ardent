import { Sparkles, Inbox } from 'lucide-react';
import { cleanerColours } from '../lib/cleanerRegistry';

export function Card({ children, className = '', ...props }) {
  return (
    <div
      className={`bg-card rounded-3xl border border-black/[0.04] shadow-[var(--shadow-card)] transition-shadow ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}

export function CleanerDot({ id, size = 8 }) {
  const colour = cleanerColours[id]?.hex || '#999';
  return (
    <span
      className="inline-block rounded-full shrink-0"
      style={{ width: size, height: size, backgroundColor: colour }}
    />
  );
}

export function CleanerTag({ id }) {
  const c = cleanerColours[id];
  if (!c) return null;
  return (
    <span className="inline-flex items-center gap-1.5 text-sm text-charcoal-soft">
      <CleanerDot id={id} />
      {c.name}
    </span>
  );
}

// Small overlapping avatar stack for appointments with more than one cleaner.
export function CleanerAvatarStack({ primary, secondary, size = 22 }) {
  const ids = [primary, secondary].filter(Boolean);
  return (
    <div className="flex items-center -space-x-1.5">
      {ids.map((id, i) => {
        const c = cleanerColours[id];
        if (!c) return null;
        return (
          <div
            key={id}
            title={c.name}
            className="rounded-full flex items-center justify-center text-white font-medium ring-2 ring-white"
            style={{ backgroundColor: c.hex, width: size, height: size, fontSize: size * 0.4, zIndex: ids.length - i }}
          >
            {c.name.slice(0, 1)}
          </div>
        );
      })}
    </div>
  );
}

const statusStyles = {
  Paid: 'bg-status-green-bg text-status-green',
  Completed: 'bg-status-green-bg text-status-green',
  Pass: 'bg-status-green-bg text-status-green',
  Available: 'bg-status-green-bg text-status-green',
  Draft: 'bg-status-blue-bg text-status-blue',
  Scheduled: 'bg-status-blue-bg text-status-blue',
  'On Site': 'bg-status-blue-bg text-status-blue',
  Overdue: 'bg-status-red-bg text-status-red',
  'Attention needed': 'bg-status-amber-bg text-status-amber',
  Pending: 'bg-status-amber-bg text-status-amber',
  Travelling: 'bg-status-amber-bg text-status-amber',
  'In Progress': 'bg-status-amber-bg text-status-amber',
  Finished: 'bg-sage-light text-charcoal-soft',
};

export function StatusPill({ status }) {
  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${statusStyles[status] || 'bg-sage-light text-charcoal-soft'}`}
    >
      {status}
    </span>
  );
}

// Signature element: the premium "AI Summary" card — styled like a warm,
// handwritten note from someone who knows the client, not a generic AI box.
export function AISummary({ children, title = 'AI Summary' }) {
  return (
    <div className="relative bg-gold-light/60 border border-gold/25 rounded-3xl p-5 pl-6 shadow-[var(--shadow-soft)]">
      <div className="absolute left-0 top-4 bottom-4 w-[3px] bg-gold/50 rounded-full" />
      <div className="flex items-center gap-2 mb-2">
        <Sparkles size={14} className="text-gold" strokeWidth={2} />
        <span className="font-display text-[13px] tracking-wide text-charcoal-soft uppercase">{title}</span>
        <span className="ml-auto text-[10px] uppercase tracking-wide text-gold/80 bg-gold/10 px-2 py-0.5 rounded-full">
          Ardent OS
        </span>
      </div>
      <p className="text-[15px] leading-relaxed text-charcoal font-display italic">{children}</p>
    </div>
  );
}

// Backwards-compatible alias used by earlier pages.
export const FieldNote = AISummary;

export function SectionHeading({ eyebrow, title, action }) {
  return (
    <div className="flex items-end justify-between mb-5 flex-wrap gap-3">
      <div>
        {eyebrow && <div className="text-xs uppercase tracking-wide text-teal font-medium mb-1">{eyebrow}</div>}
        <h2 className="font-display text-2xl text-charcoal">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ icon: Icon = Inbox, title, body }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-14 px-6">
      <div className="w-12 h-12 rounded-2xl bg-sage-light flex items-center justify-center text-teal-dark mb-4">
        <Icon size={20} strokeWidth={1.75} />
      </div>
      <div className="font-display text-lg text-charcoal mb-1">{title}</div>
      {body && <p className="text-sm text-charcoal-soft max-w-xs">{body}</p>}
    </div>
  );
}
